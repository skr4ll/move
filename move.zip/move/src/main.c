  /* MOVE-X TRY ZUSAMMENSETZUNG AUS
	ALLEN CODE TRIES BIS JETZT (NC.C und TEST.C)
	BACKUP LIEGT IN BACKUPARRPROG.C  und BACKUPMOVEX.C*/
#include <ncurses.h>

void menu();


int  main(void){
initscr ();
noecho ();
curs_set(0);

	menu();


endwin();

}
