#include <ncurses.h>
#include <stdio.h>

void updateMap();
void map1(){
//MAZE 1

int sizX = 25;
int sizY = 10;

int maxX = sizX - 1;
int maxY = sizY - 1;

char maze1[sizX][sizY];
int x = 0, y = 0;

//SETZEN DES ARRAYS:

//Randspalten:

for(x = 0; x < sizX; x++){
	maze1[x][0]='X';   								//y=0 untere seite des rechtecks
	maze1[x][maxY]='X';
	//printf("test2");								//y=max obere seite des rechtecks
}

for (y= 0; y < sizY; y++){
	maze1[0][y]='X';									//x=0 linke seite des rechtecks
	maze1[maxX][y]='X';
	//printf("test3");								//x=max rechte seite des rechtecks
}

x = 1;
y = 1;

//Innenspalten

for ( x = 1; x < maxX; x++){
	for(y = 1; y < maxY; y++){
		maze1[x][y] = ' ';
		//printf("test4");
	}
}

maze1[1][3] = 'X';
maze1[2][1] = 'X';  maze1[2][3] = 'X'; maze1[2][4] = 'X'; maze1[2][5] = 'X'; maze1[2][7] = 'X';
maze1[3][7] = 'X';
maze1[4][1] = 'X';  maze1[4][2] = 'X'; maze1[4][3] = 'X'; maze1[4][4] = 'X'; maze1[4][5] = 'X'; maze1[4][6] = 'X'; maze1[4][7] = 'X';
maze1[6][2] = 'X';  maze1[6][3] = 'X'; maze1[6][5] = 'X'; maze1[6][6] = 'X'; maze1[6][7] = 'X'; maze1[6][8] = 'X';
maze1[8][2] = 'X';  maze1[8][3] = 'X'; maze1[8][4] = 'X'; maze1[8][5] = 'X'; maze1[8][6] = 'X'; maze1[8][7] = 'X';
maze1[9][2] = 'X';  maze1[9][7] = 'X';
maze1[10][2] = 'X'; maze1[10][5] = 'X'; maze1[10][7] = 'X';
maze1[11][4] = 'X'; maze1[11][5] = 'X'; maze1[11][6] = 'X'; maze1[11][7] = 'X';
maze1[12][1] = 'X'; maze1[12][2] = 'X'; maze1[12][6] = 'X';
maze1[13][2] = 'X'; maze1[13][3] = 'X'; maze1[13][4] = 'X'; maze1[13][6] = 'X'; maze1[13][8] = 'X';
maze1[14][4] = 'X'; maze1[14][6] = 'X'; maze1[14][7] = 'X'; maze1[14][8] = 'X';
maze1[15][1] = 'X'; maze1[15][2] = 'X';
maze1[16][4] = 'X'; maze1[16][6] = 'X'; maze1[16][7] = 'X';
maze1[17][2] = 'X'; maze1[17][3] = 'X'; maze1[17][4] = 'X'; maze1[17][7] = 'X';
maze1[18][3] = 'X'; maze1[18][4] = 'X'; maze1[18][5] = 'X'; maze1[18][6] = 'X';
maze1[19][1] = 'X'; maze1[19][2] = 'X'; maze1[19][8] = 'X';
maze1[20][4] = 'X'; maze1[20][5] = 'X'; maze1[20][6] = 'X'; maze1[20][7] = 'X'; maze1[20][8] = 'X';
maze1[21][2] = 'X'; maze1[21][3] = 'X'; maze1[21][4] = 'X'; maze1[21][8] = 'X';
maze1[22][4] = 'X'; maze1[22][6] = 'X'; maze1[22][8] = 'X';
maze1[23][2] = 'X'; maze1[23][6] = 'X'; maze1[23][8] = 'F';
//maze1[24][2] = 'X'; maze1[24][6] = 'X'; maze1[24][8] = 'F';


updateMap(sizX, sizY, maze1);

}
