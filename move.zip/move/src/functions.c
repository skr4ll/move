#include <ncurses.h>
#include <stdio.h>
#include <stdlib.h>

void map1();
void menu()
{
char  auswahl = '0';

start_color();
init_pair(1, COLOR_RED, COLOR_BLACK);
init_pair(2, COLOR_BLUE, COLOR_BLACK);
WINDOW * menu = newwin(0, 0, 0,0);
	wattron(menu, COLOR_PAIR(1));
	wprintw(menu, "\n\nsssssssss k                    l  l \n#\t  #  # rrrr #######    #  #  ####\n#\t  # #  #   #       #   #  #  #\n######### ##   #   #       #   #  #  #\n\t# ##   #   #       #   #  #  ####\n\t# # #  #   #       #   #  #     #\n######### #  # #   #########   #  #  ssss\n                           a\n                           aaa");
	wattroff(menu, COLOR_PAIR(1));

	wattron(menu, COLOR_PAIR(2));
	wprintw(menu,"\n    #     #    ##### #####  ####\n   # #   # #   #   #    #   #\n  #   # #   #  #####   #    ####\n #     #     # #   #  ##### #\n                            ####\n");
	wattroff(menu, COLOR_PAIR(2));
	wprintw(menu, "\n\n\t1) Starten\n");
	wprintw(menu, "\t2) Beenden");

auswahl = wgetch(menu);

	if ( auswahl == '2' ){
		endwin();
		exit(0);
	}
	else if ( auswahl == '1' ){
		wclear(menu);
		refresh();
		map1();
	}
}

void updateMap(int X, int Y, char curMap[X][Y]){

WINDOW * fenster = newwin( 150, 270, 0, 0 );

int xCord = 1, yCord = 1, x = 0, y = 0, i = 0, j = 0, sizX = X, sizY = Y;

char eingabe = '0';
//Benutzereingabe:


int checkCordX, checkCordY = 1;
while (1)
	{

		switch (eingabe){

			case 's' :
			checkCordY = yCord + 1;
					if (curMap[xCord][checkCordY] != 'X'){

					yCord = yCord + 1;
					curMap[xCord][yCord] = 'J';
					curMap[xCord][yCord - 1] = ' ';
					}
			break;

			case 'w' :
			checkCordY = yCord - 1;
					if (curMap[xCord][checkCordY] != 'X'){

					yCord = yCord - 1;
					curMap[xCord][yCord] = 'J';
					curMap[xCord][yCord + 1] = ' ';
					}
			break;

			case 'd' :
			checkCordX = xCord + 1;
					if (curMap[checkCordX][yCord] != 'X'){

					xCord = xCord + 1;
					curMap[xCord][yCord] = 'J';
					curMap[xCord - 1][yCord] = ' ';
					}
			break;

			case 'a' :
			checkCordX = xCord - 1;
					if (curMap[checkCordX][yCord] != 'X'){
					xCord = xCord - 1;
					curMap[xCord][yCord] = 'J';
					curMap[xCord + 1][yCord] = ' ';
					}
			break;

		}


//J auf der aktuellen Map hin- und her bewegen (aka Ausgabe):

for (i = 0; i < sizY; i++ ){

	WINDOW * info = newwin(0, 0, 0,0);													//KOORDINATEN INFO
			mvwprintw(info, 0,0, "X: %i Y: %i", xCord, yCord);
			wrefresh(info);
			printw("\n");

			for(j = 0; j < sizX; j++){
				x = i + 1;
				y = j + 1;

				mvwprintw(fenster, x,y, "%c", curMap[j][i]);

			}


		}

eingabe = wgetch(fenster);

	}
}






